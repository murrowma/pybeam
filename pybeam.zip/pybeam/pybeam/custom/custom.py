"""
File: custom.py
Description: Functions for the pybeam.default sub-module.
Creator: Matt Murrow
Email: matthew.a.murrow@vanderbilt.edu

"""

# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #

"""
Import Python modules and other functions required by pybeam.

"""

# import python modules
import numpy as np
import matplotlib.pyplot as plt
import pymc as pm
import aesara.tensor as at
import arviz as az
import copy
import warnings
import sys
from scipy import interpolate

# import pybeam functions
# from . import functions_prebuilt
# from . import loglike_class

import loglike_class

# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #

"""

"""

def test_functions(model_dir, phi, x, t):

    """
    Check if function inputs are correct.

    """

    # check if model_dir is input properly
    if (isinstance(model_dir, str) == False):
        raise RuntimeError("model_dir must be a string containing the full path of your model file.")

    # import functions file
    sys.path.insert(1, model_dir)
    import functions_custom

    # chceck if function is input properly
    functions_list = ['drift',
                      'diffusion',
                      'upper_threshold',
                      'lower_threshold',
                      'contamination_strength',
                      'contamination_probability',
                      'modify_dt']

    # check if phi is input properly
    if (isinstance(phi, dict) == False):
        raise RuntimeError("phi must be a dictionary.")

    # check if input array phi has same amount of parameters as N_phi
    check = functions_custom.model_check(len(phi));
    if (check == False):
        raise RuntimeError("Length of dictionary phi does not equal N_phi.")

    # check if dictionary phi has the correct keys (0, 1, ... , N_phi)
    for ii in range(len(phi)):
        if ( 'phi[' + str(ii) + ']' in phi):
            continue
        else:
            raise RuntimeError("Keys for phi must be 'phi[0]', 'phi[1]', ... , 'phi[N_phi-1]'.")

    # check if x is input properly
    if (isinstance(x, (float,int)) == False):
        raise RuntimeError("x must be of type float or int.")

    # check if t is input properly
    if (isinstance(t, (float,int)) == False):
        raise RuntimeError("t must be of type float or int.")

    """
    Load input dictionary phi into list.

    """
        
    phi_list = [0]*len(phi)
    for ii in range(len(phi)):
        phi_list[ii] = phi['phi[' + str(ii) + ']']

    """
    Run relevant function, return their outputs.

    """

    functions_out = {}
    for ii in range(len(functions_list)):
        functions_out[functions_list[ii]] = functions_custom.model_functions_check(functions_list[ii], phi_list, x, t)

    return functions_out

# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #
# ---------------------------------------------------------------------- #

def simulate(model_dir, N_sims, phi, dt = 0.0001, seed = False):

    """
    Check if function input(s) are of the correct form.

    """

    # check if model_dir is input properly
    if (isinstance(model_dir, str) == False):
        raise RuntimeError("model_dir must be a string containing the full path of your model file.")

    # import functions file
    sys.path.insert(1, model_dir)
    import functions_custom

    # check if N_sims is input properly
    if (isinstance(N_sims, int) == False):
        raise RuntimeError("N_sims must be a positive integer.")
    if (N_sims <= 0):
        raise RuntimeError("N_sims must be more than zero.")

    # check if phi is input properly
    if (isinstance(phi, dict) == False):
        raise RuntimeError("phi must be a dictionary.")

    # check if input array phi has same amount of parameters as N_phi
    check = functions_custom.model_check(len(phi));
    if (check == False):
        raise RuntimeError("Length of dictionary phi does not equal N_phi.")

    # check if dictionary phi has the correct keys ('phi[0]', 'phi[1]', ... , 'phi[N_phi-1]')
    for ii in range(len(phi)):
        if ( 'phi[' + str(ii) + ']' in phi):
            continue
        else:
            raise RuntimeError("Keys for phi must be 'phi[0]', 'phi[1]', ... , 'phi[N_phi-1]'.")

    # check if seed is input properly
    if (seed != False):
        if (isinstance(seed, int) == False):
            raise RuntimeError("seed must be of type int.")
    elif (seed < 0):
        raise RuntimeError("seed must be a positive integer.")

    # check if dt is input properly
    if (isinstance(dt, float) == False):
        raise RuntimeError("dt must be of type float.")
    elif (dt <= 0.0):
        raise RuntimeError("dt must be more than zero.")

    """
    Parse model and phi inputs.

    """
        
    phi_list = [0]*len(phi)
    for ii in range(len(phi)):
        phi_list[ii] = phi['phi[' + str(ii) + ']']

    """
    Simulate model, output dictonary of reaction times.

    """
        
    # generate random seed if no seed set
    if (seed == False):
        seed = np.random.randint(0,100000)

    rt = np.asarray( functions_constant.simulate(N_sims, phi_bulk, psi_bulk, 'constant', 'constant', 'constant', dt, seed) )



