from setuptools import setup
from Cython.Build import cythonize

setup(
    name='functions_default',
    ext_modules=cythonize("functions_default.pyx"),
    zip_safe=False,
)