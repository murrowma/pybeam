# module imports
import numpy as np
import aesara.tensor as at

# define a theano Op for our likelihood function
class LogLike(at.Op):

    """
    Specify what type of object will be passed and returned to the Op when it is
    called. We pass a vector of values phi (the parameters that define our model)
    and return a single "scalar" value (the log-likelihood).

    """

    itypes = [at.dvector, at.dvector]  # expects a vector of parameter values when called
    otypes = [at.dscalar]  # outputs a single scalar value (the loglikelihood)

    def __init__(self, loglike, w_dist, tnd_dist, N_tnd, mu_dist, N_mu, N_deps, dt_scale, dt_interp_scale, dt_interp_overide, rtu, rtl, rt_max):
    
        """
        Initialise the Op with various things that our log-likelihood function
        requires. Below are the things that are needed in this program.

        Parameters
        ----------
        loglike:
            The log-likelihood function we've defined.
        N_deps:
            Number of spatial mesh points.
        dt_scale:
            Used to set the time step.
        rt_max:
            Calculate first passage time distribution until this time.
        rtu:
            Upper decision threhsold crossing times.
        rtl:
            Lower decision threhsold crossing times.
        output_loglike:
            If 1, output loglike. If 0, output first passage time distribution.

        """

        # add inputs as class attributes
        self.likelihood = loglike
        self.w_dist = w_dist
        self.tnd_dist = tnd_dist
        self.N_tnd = N_tnd
        self.mu_dist = mu_dist
        self.N_mu = N_mu
        self.N_deps = N_deps
        self.dt_scale = dt_scale
        self.dt_interp_scale = dt_interp_scale
        self.dt_interp_overide = dt_interp_overide
        self.rtu = rtu
        self.rtl = rtl
        self.rt_max = rt_max

    def perform(self, node, inputs, outputs):
    
        # the method that is used when calling the Op
        (phi, psi) = inputs  # contains variables

        # call the log-likelihood function
        logl = self.likelihood(phi, psi, self.w_dist, self.tnd_dist, self.N_tnd, self.mu_dist, self.N_mu, self.N_deps, self.dt_scale, self.dt_interp_scale, self.dt_interp_overide, self.rtu, self.rtl, self.rt_max)

        # output the log-likelihood
        outputs[0][0] = np.array(logl)