from setuptools import setup
from Cython.Build import cythonize

setup(
    name=["functions_constant",
          "functions_leakage"
          "functions_changing_thresholds"
          "functions_UGM"
          "functions_UGM_flip"],
    ext_modules=cythonize(["functions_constant.pyx", 
                           "functions_leakage.pyx",
                           "functions_changing_thresholds.pyx",
                           "functions_UGM.pyx",
                           "functions_UGM_flip.pyx"]),
    zip_safe=False,
)