from setuptools import setup, find_packages
from Cython.Build import cythonize

setup(name='pybeam',
      version='0.2',
      packages=find_packages(),
      ext_modules = cythonize(["pybeam/precoded/functions_constant.pyx", 
                               "pybeam/precoded/functions_leakage.pyx",
                               "pybeam/precoded/functions_moving_thresholds.pyx",
                               "pybeam/precoded/functions_UGM.pyx",
                               "pybeam/precoded/functions_UGM_flip.pyx"]),
      zip_safe=False)
